using System;
using System.Collections.Generic;
using System.Text;
using AndrewTweddle.ORToolkit.DynamicProgramming;
using AndrewTweddle.ORToolkit.DynamicProgramming.StateCentric;

namespace AndrewTweddle.ORToolkit.DynamicProgramming.SampleCode.KnapsackProblem
{
    public static class KnapsackProblem
    {
        public static SolutionSet<KnapsackState, int> 
            Solve(double totalWeight, KnapsackItem[] items)
        {
            KnapsackState initialState 
                = new KnapsackState(totalWeight, items);
            StateCentricDynamicProgram<KnapsackState, int> dynamicProgram
                = new StateCentricDynamicProgram<KnapsackState, int>();
            return dynamicProgram.Solve(initialState);
        }
    }
}
