using System;
using System.Collections.Generic;
using System.Text;

namespace AndrewTweddle.ORToolkit.DynamicProgramming.SampleCode.KnapsackProblem
{
    public class KnapsackItem
    {
        private double weight = 1.0;
        private double value = 0.0;
        private int quantity = int.MaxValue;

        public int Quantity
        {
            get { return quantity; }
            set { quantity = value; }
        }

        public double Weight
        {
            get { return weight; }
            set { weight = value; }
        }

        public double Value
        {
            get { return this.value; }
            set { this.value = value; }
        }

        public KnapsackItem(double weight, double value)
        {
            this.weight = weight;
            this.value = value;
        }

        public KnapsackItem(double weight, double value, int quantity)
            : this(weight, value)
        {
            this.quantity = quantity;
        }
    }
}
