using System;
using System.Collections.Generic;
using System.Text;
using AndrewTweddle.ORToolkit.DynamicProgramming.StateCentric;

namespace AndrewTweddle.ORToolkit.DynamicProgramming.SampleCode.KnapsackProblem
{
    /* The decision is an integer, namely how many of the 
     * first item (in the list of remaining items) to include:
     */
    public class KnapsackState : IState<int>
    {
        private KnapsackItem[] items;
        private double weightRemaining;

        public KnapsackState(double weightRemaining, KnapsackItem[] items)
        {
            this.weightRemaining = weightRemaining;
            this.items = items;
        }

        #region IState<bool> Members

        public IEnumerable<int> GenerateDecisions()
        {
            if (items.Length == 0)
            {
                yield break;
            }
            else
            {
                int maxCount 
                    = (int) Math.Floor(weightRemaining / items[0].Weight);
                int qtyAvailable = items[0].Quantity;

                if (maxCount > qtyAvailable)
                {
                    maxCount = qtyAvailable;
                }

                for (int itemCount = 0;
                    itemCount <= maxCount;
                    itemCount++)
                {
                    yield return itemCount;
                }
            }
        }

        public CommonDynamicProgramBase.BranchStatus GetBranchStatus(
            int stage)
        {
            if (items.Length == 0)
            {
                return CommonDynamicProgramBase.BranchStatus.Complete;
            }
            else
            {
                return CommonDynamicProgramBase.BranchStatus.Incomplete;
            }
        }

        public double GetDecisionValue(int decision, int stage)
        {
            /* The decision is how many of the i-th item to include: */
            if (items.Length > 0)
            {
                return items[0].Value * decision;
            }
            else
            {
                return 0;
            }
        }

        public IState<int> GenerateNewState(int decision, int stage)
        {
            double newWeightRemaining
                = weightRemaining
                    - ( decision == 0
                        ? 0
                        : decision * items[0].Weight
                      );
            KnapsackItem[] remainingItems;

            if (items.Length > 1)
            {
                remainingItems = new KnapsackItem[items.Length - 1];
                Array.Copy(items, 1, remainingItems, 0, items.Length - 1);
            }
            else
            {
                remainingItems = new KnapsackItem[0];
            }

            return new KnapsackState(newWeightRemaining, remainingItems);
        }

        #endregion
    }
}
