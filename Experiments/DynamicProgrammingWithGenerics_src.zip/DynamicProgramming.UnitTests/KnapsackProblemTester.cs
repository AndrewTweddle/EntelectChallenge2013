using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using AndrewTweddle.ORToolkit.DynamicProgramming.SampleCode.KnapsackProblem;

namespace AndrewTweddle.ORToolkit.DynamicProgramming.UnitTests
{
    [TestFixture]
    public class KnapsackProblemTester
    {
        [Test]
        public void TestKnapsackAlgorithm()
        {
            List<KnapsackItem> items = new List<KnapsackItem>();
            items.Add(new KnapsackItem(2, 110));
            items.Add(new KnapsackItem(3, 160));
            items.Add(new KnapsackItem(5, 260));
            items.Add(new KnapsackItem(4, 220));

            SolutionSet<KnapsackState, int> solutions
                = KnapsackProblem.Solve(21, items.ToArray());

            if (!solutions.IsFeasible)
            {
                Assert.Fail(
                    "The knapsack problem has no feasible solution.");
            }
            else
            {
                if (solutions.Value != 1150)
                {
                    Assert.Fail(
                        string.Format(
                            "The calculated value of {0} is incorrect (it should be 1150)!",
                            solutions.Value));
                }
            }
        }

        [Test]
        public void EnumerateKnapsackSolutions()
        {
            Console.WriteLine(
                "*** Solutions to knapsack problem: ***");
            Console.WriteLine();

            List<KnapsackItem> items = new List<KnapsackItem>();
            items.Add(new KnapsackItem(2, 110));
            items.Add(new KnapsackItem(3, 160));
            items.Add(new KnapsackItem(5, 260));
            items.Add(new KnapsackItem(4, 220));  

            SolutionSet<KnapsackState, int> solutions
                = KnapsackProblem.Solve(21, items.ToArray());

            if (solutions.IsFeasible)
            {
                Console.WriteLine(
                    "[{0} solutions each giving a maximum profit of {1}]",
                    solutions.SolutionCount, solutions.Value);
                Console.WriteLine();

                for (int i = 0; i < solutions.SolutionCount; i++)
                {
                    Console.WriteLine("Solution {0}:", i);
                    int[] decisions
                        = solutions.GetDecisionsForSolution(i);

                    for (int d = 0; d < decisions.Length; d++)
                    {
                        int qtyToPack = decisions[d];

                        Console.WriteLine(
                            "  {0} x Item {1} [Unit weight = {2}; profit = {3}]",
                            qtyToPack, d+1, 
                            items[d].Weight, items[d].Value);
                    }
                    Console.WriteLine();
                }
            }

            Console.WriteLine();
        }
    }
}
