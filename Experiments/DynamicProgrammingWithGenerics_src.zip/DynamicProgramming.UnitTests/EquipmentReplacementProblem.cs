using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using AndrewTweddle.ORToolkit.DynamicProgramming;

namespace AndrewTweddle.ORToolkit.DynamicProgramming.UnitTests
{
    [TestFixture]
    public class EquipmentReplacementProblem
    {
        [Test]
        public void Solve()
        {
            /* The problem is to optimise the profit over 5 years
             * of a machine which is currently 1 year old.
             * At each time period, the decision is whether to 
             * replace the machine (at a cost of 22).
             * The profit is zero on a machine that is 5 years old.
             * Otherwise the profit is 26 - 2t - 0.5 t^2
             * where t is the age of the machine at the start of the period
             * (but after the decision is made).
             * 
             *   [Problem taken from my postgraduate university
             *    course notes in dynamic programming.]
             * 
             */

            Console.WriteLine(
                "*** EquipmentReplacementProblem.Solve(): ***");
            Console.WriteLine();

            /* The state variable is the age of the equipment.
             * The decision is whether to replace it.
             */
            DynamicProgram<int, bool> problem 
                = new DynamicProgram<int, bool>();

            problem.ValueCalculator 
                = delegate(int age, bool replace, int stage)
                    {
                        if (replace)
                        {
                            return 4;
                                /* Profit of 26 less 
                                 * replacement cost of 22 
                                 */
                        }
                        else
                        {
                            if (age >= 5)
                            {
                                return 0;
                            }
                            else
                            {
                                return 26 - 2 * age - 0.5 * age * age;
                            }
                        }
                    };

            problem.DecisionGenerator = delegate(int age)
            {
                bool[] choices = { false, true };
                return choices;

                /* Note: 
                 * If we were using a normal delegate
                 * instead of an anonymous delegate,
                 * we could do the following instead:
                  
                yield return false;
                yield return true;
                 
                 */
            };

            problem.StoppingTest = delegate(int age, int stage)
            {
                if (stage == 6)
                {
                    return CommonDynamicProgramBase.BranchStatus.Complete;
                }
                else
                {
                    return CommonDynamicProgramBase.BranchStatus.Incomplete;
                }
            };

            problem.StateTransformation 
                = delegate(int age, bool replace, int stage)
            {
                if (replace)
                {
                    return 1;  
                        /* The new machine will be 1 year old in the next stage */
                }
                else
                {
                    return ++age; /* The same machine is 1 year older */
                }
            };

            SolutionSet<int, bool> solutions = problem.Solve(1);
                /* Pass 1 as initial state as this 
                 * is the current age of the machine 
                 */

            if (!solutions.IsFeasible)
            {
                Assert.Fail("No feasible solution");
            }
            else
            {
                if (solutions.Value != 91)
                {
                    Assert.Fail("Solution value {0} incorrect", 
                        solutions.Value);
                }
                else
                {
                    int currAge = 1;

                    for (int i = 0; i < solutions.SolutionCount; i++)
                    {
                        Console.WriteLine("Solution {0}:", i);

                        foreach (SolutionNode<int, bool> solNode
                            in solutions[i])
                        {
                            Console.WriteLine(
                                "  age = {0}; {1}profit = {2}", 
                                currAge, 
                                solNode.DecisionChosen 
                                    ? "replace; " 
                                    : String.Empty,
                                solNode.Contribution);
                            currAge = solNode.PostDecisionState;
                        }
                        Console.WriteLine("  final age = {0}", currAge);
                        Console.WriteLine();
                    }
                }
            }

            Console.WriteLine();
        }
    }
}
