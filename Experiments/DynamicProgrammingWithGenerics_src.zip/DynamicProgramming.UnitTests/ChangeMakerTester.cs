using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using AndrewTweddle.ORToolkit.DynamicProgramming;
using AndrewTweddle.ORToolkit.DynamicProgramming.SampleCode.ChangeMaker;

namespace AndrewTweddle.ORToolkit.DynamicProgramming.UnitTests
{
    [TestFixture]
    public class ChangeMakerTester
    {
        [Test]
        public void TestInfeasibleSolution()
        {
            ChangeMaker chMaker = new ChangeMaker();
            State initialState = new State(101 /* = $1.01 */,
                new int[] { 5, 10, 25, 30 });
            SolutionSet<State, Decision> solutions 
                = chMaker.Solve(initialState);

            Assert.IsTrue(!solutions.IsFeasible);
        }

        [Test]
        public void TestNumberOfWaysOfMakingChange()
        {
            ChangeMaker chMaker = new ChangeMaker();
            State initialState = new State(100 /* = $1 */,
                new int[] {1, 5, 10, 25, 50});

            Assert.IsTrue(
                chMaker.CountWaysOfMakingChange(initialState) == 292);
        }

        [Test]
        public void TestNumberOfWaysOfMakingChangeWithLeastCoins()
        {
            ChangeMaker chMaker = new ChangeMaker(
                ChangeMaker.GoalType.UseLeastNumberOfCoins);

            State initialState = new State(40,
                new int[] { 1, 5, 10, 25, 50 });

            Assert.IsTrue(
                chMaker.CountWaysOfMakingChange(initialState) == 1);
        }

        [Test]
        public void EnumerateWaysOfMakingChangeWithLeastCoins()
        {
            Console.WriteLine(
                "*** EnumerateWaysOfMakingChangeWithLeastCoins(): ***");
            Console.WriteLine();

            ChangeMaker chMaker = new ChangeMaker(
                ChangeMaker.GoalType.UseLeastNumberOfCoins);

            State initialState = new State(40,
                new int[] { 1, 5, 10, 25, 50 });

            SolutionSet<State, Decision> solutions
                = chMaker.Solve(initialState);

            chMaker.WriteSolutionSet(solutions, Console.Out);

            Console.WriteLine();
        }

        [Test]
        public void TestNumberOfWaysOfMakingChangeWithOnlyOne50()
        {
            ChangeMaker chMaker = new ChangeMaker();
            State initialState = new State(100 /* = $1 */,
                new Denomination[] 
                    {   new Denomination(1),
                        new Denomination(5), 
                        new Denomination(10), 
                        new Denomination(25), 
                        new Denomination(50, 1) 
                    });

            Assert.IsTrue(
                chMaker.CountWaysOfMakingChange(initialState) == 291);
                    /* There is one less solution, since two 50's 
                     * can't be used any more.
                     */
        }

        [Test]
        public void EnumerateWaysOfMakingChange()
        {
            Console.WriteLine("*** EnumerateWaysOfMakingChange(): ***");
            Console.WriteLine();

            ChangeMaker chMaker = new ChangeMaker();
            State initialState = new State(100 /* = $1 */,
                new int[] {1, 5, 10, 25, 50});
            SolutionSet<State, Decision> solutions
                = chMaker.Solve(initialState);

            chMaker.WriteSolutionSet(solutions, Console.Out);

            Console.WriteLine();
        }

        [Test]
        public void EnumerateWaysOfMakingChangeWithOnlyTwoTensOne25And50()
        {
            Console.WriteLine(
                "*** EnumerateWaysOfMakingChangeWithOnlyTwoTensOne25And50(): ***");
            Console.WriteLine();

            ChangeMaker chMaker = new ChangeMaker();
            State initialState = new State(100 /* = $1 */,
                new Denomination[] 
                    {   new Denomination(1),
                        new Denomination(5), 
                        new Denomination(10, 2), 
                        new Denomination(25, 1), 
                        new Denomination(50, 1) 
                    });
            SolutionSet<State, Decision> solutions
                = chMaker.Solve(initialState);

            chMaker.WriteSolutionSet(solutions, Console.Out);
            Console.WriteLine();
        }
    }
}
