using System;
using System.Collections.Generic;
using System.Text;

namespace AndrewTweddle.ORToolkit.DynamicProgramming.StateCentric
{
    public interface IState<TDecision>
    {
        IEnumerable<TDecision> GenerateDecisions();
        CommonDynamicProgramBase.BranchStatus GetBranchStatus(int stage);
        double GetDecisionValue(TDecision decision, int stage);
        IState<TDecision> GenerateNewState(TDecision decision, int stage);
            /* NB: The new IState instance must be separate from the 
             *     current IState, which should be treated as immutable.
             */
    }
}
