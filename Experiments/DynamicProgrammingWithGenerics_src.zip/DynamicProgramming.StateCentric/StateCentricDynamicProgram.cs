using System;
using System.Collections.Generic;
using System.Text;

namespace AndrewTweddle.ORToolkit.DynamicProgramming.StateCentric
{
    public class StateCentricDynamicProgram<TState, TDecision>
        : DynamicProgramBase<TState, TDecision> 
        where TState : class, IState<TDecision>
    {
        public SolutionNodeStorageType SolutionStorageType
        {
            get { return GetSolutionStorageType(); }
            set { SetSolutionStorageType(value); }
        }

        protected override IEnumerable<TDecision> GenerateDecisions(
            TState state)
        {
            return state.GenerateDecisions();
        }
         
        protected override TState GenerateNewState(
            TState state, TDecision decision, int stage)
        {
            return state.GenerateNewState(decision, stage) as TState;
        }

        protected override BranchStatus GetBranchStatus(
            TState state, int stage)
        {
            return state.GetBranchStatus(stage);
        }

        protected override double GetDecisionValue(TState priorState,
            TDecision decision, int stage)
        {
            return priorState.GetDecisionValue(decision, stage);
        }
    }
}
