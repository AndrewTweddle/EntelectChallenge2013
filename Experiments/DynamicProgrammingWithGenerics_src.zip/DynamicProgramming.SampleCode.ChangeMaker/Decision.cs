using System;
using System.Collections.Generic;
using System.Text;

namespace AndrewTweddle.ORToolkit.DynamicProgramming.SampleCode.ChangeMaker
{
    /* Note: A decision to use a certain number of coins 
     *       of a particular denomination implies that 
     *          a) that denomination, and 
     *          b) all prior denominations (in the array of denominations)
     *       will no longer be considered in subsequent stages 
     *       of the dynamic program.
     */
    public class Decision
    {
        private Denomination coinDenomination;
        private int coinCount;

        public Denomination CoinDenomination
        {
            get { return coinDenomination; }
        }

        public int CoinCount
        {
            get { return coinCount; }
        }

        public Decision(Denomination coinDenomination, int coinCount)
        {
            this.coinDenomination = coinDenomination;
            this.coinCount = coinCount;

            /* TODO: Ideally one should also check that 
             * 0 < coinCount < denomination.AvailableQuantity
             */
        }
    }

}
