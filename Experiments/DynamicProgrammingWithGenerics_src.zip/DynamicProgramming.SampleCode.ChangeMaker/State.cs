using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace AndrewTweddle.ORToolkit.DynamicProgramming.SampleCode.ChangeMaker
{
    public class State
    {
        private int totalRemaining;
        private ReadOnlyCollection<Denomination> denominations;

        public int TotalRemaining
        {
            get { return totalRemaining; }
        }

        /* Coin denominations still available: */
        public ReadOnlyCollection<Denomination> Denominations
        {
            get { return denominations; }
        }

        public State(int totalRemaining, Denomination[] denominations)
        {
            this.totalRemaining = totalRemaining;
            Denomination[] denominationsClone 
                = new Denomination[denominations.Length];
            denominations.CopyTo(denominationsClone, 0);
            this.denominations 
                = new ReadOnlyCollection<Denomination>(denominationsClone);
        }

        public State(int totalRemaining, int[] denominations)
        {
            this.totalRemaining = totalRemaining;

            Denomination[] denominationsArray 
                = new Denomination[denominations.Length];

            for (int i = 0; i < denominations.Length; i++)
            {
                denominationsArray[i] = new Denomination(denominations[i]);
            }
            this.denominations 
                = new ReadOnlyCollection<Denomination>(denominationsArray);
        }
    }

}
