using System;
using System.Collections.Generic;
using System.Text;
using AndrewTweddle.ORToolkit.DynamicProgramming;

namespace AndrewTweddle.ORToolkit.DynamicProgramming.SampleCode.ChangeMaker
{
    /* The ChangeMaker class generalises and solves the following problem
     * (from a competition at the DevDays 2005 conference in Durban):
     * 
     * Assuming you have enough coins of denomination 1, 5, 10, 25 and 50
     * cents, how many ways are there to make change for a dollar?
     * 
     */
    public class ChangeMaker : DynamicProgramBase<State, Decision>
    {
        public enum GoalType
        {
            AllWaysOfMakingChange,
            UseLeastNumberOfCoins
        }

        private GoalType goal;

        public GoalType Goal
        {
            get { return goal; }
            set { goal = value; }
        }

        protected override IEnumerable<Decision> GenerateDecisions(
            State state)
        {
            foreach (Denomination denom in state.Denominations)
            {
                int maxCount = Math.Min(denom.QuantityAvailable,
                    state.TotalRemaining / denom.CoinValue);

                if (maxCount == 0)
                {
                    yield break;
                }
                else
                {
                    for (int coinCount = 1;
                        coinCount <= maxCount;
                        coinCount++)
                    {
                        yield return new Decision(denom, coinCount);
                    }
                }
            }
        }

        protected override BranchStatus GetBranchStatus(State state, 
            int stage)
        {
            if (state.TotalRemaining == 0)
                return BranchStatus.Complete;

            if (state.Denominations.Count == 0)
                return BranchStatus.Infeasible;

            return BranchStatus.Incomplete;
        }

        protected override double GetDecisionValue(State priorState, 
            Decision decision, int stage)
        {
            if (goal == GoalType.UseLeastNumberOfCoins)
            {
                return -decision.CoinCount;
                    /* NB: The standard formulation MAXIMISES value.
                     *     We want to MINIMISE the number of coins.
                     *     So change the sign around.
                     */
            }
            else
            {
                /* Treat all initialSolutionNodes as having zero value,
                 * so that feasibility is the only concern,
                 * not optimality:
                 */
                return 0.0;
            }
        }

        protected override State GenerateNewState(
            State state, Decision decision, int stage)
        {
            int index = -1;
            int ignoreCount = 0;
            Denomination[] availableDenominations = null;

            foreach (Denomination denom in state.Denominations)
            {
                if (index == -1)
                {
                    /* Ignore all denominations up to and including
                     * the one chosen by the decision:
                     */
                    ignoreCount++;

                    if (decision.CoinDenomination == denom)
                    {
                        /* The denomination has been found, and now there is 
                         * enough information to choose the size of the array:
                         */
                        index = 0;

                        availableDenominations = new Denomination[
                            state.Denominations.Count - ignoreCount];
                    };
                }
                else
                {
                    /* The remaining denominations are copied to the array: */
                    availableDenominations[index] = denom;
                    index++;
                }
            }

            State newState = new State(state.TotalRemaining
                - decision.CoinCount * decision.CoinDenomination.CoinValue,
                availableDenominations);

            return newState;
        }

        public int CountWaysOfMakingChange(State initialState)
        {
            SolutionSet<State, Decision> solutions
                = Solve(initialState);

            return solutions.SolutionCount;
        }

        public ChangeMaker(GoalType goal)
        {
            this.goal = goal;

            /* The state object consists of arrays of outstanding coins.
             * To reduce the memory footprint, don't store the
             * post-decision state on the SolutionNode:
             */
            SetSolutionStorageType(SolutionNodeStorageType.DecisionOnly);
        }

        public ChangeMaker(): this(GoalType.AllWaysOfMakingChange)
        {
        }

        public void WriteSolutionSet(SolutionSet<State, Decision> solutions,
            System.IO.TextWriter tw)
        {
            tw.WriteLine("[{0} solutions]", solutions.SolutionCount);
            tw.WriteLine();

            for (int i = 0; i < solutions.SolutionCount; i++)
            {
                tw.WriteLine("Solution {0}:", i);
                tw.Write("  ");
                bool isFirst = true;

                foreach (Decision dec
                    in solutions.GetDecisionsForSolution(i))
                {
                    if (isFirst)
                    {
                        isFirst = false;
                    }
                    else
                    {
                        tw.Write("; ");
                    }

                    tw.Write("{0} x {1}c", dec.CoinCount,
                        dec.CoinDenomination.CoinValue);

                }

                tw.WriteLine();
            }
        }
    }
}
