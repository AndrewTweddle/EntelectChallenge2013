using System;
using System.Collections.Generic;
using System.Text;

namespace AndrewTweddle.ORToolkit.DynamicProgramming.SampleCode.ChangeMaker
{
    public class Denomination
    {
        private int coinValue;
        private int quantityAvailable;

        public int CoinValue
        {
            get { return coinValue; }
            set { coinValue = value; }
        }

        public int QuantityAvailable
        {
            get { return quantityAvailable; }
            set 
            {
                if (value <= 0)
                {
                    throw new ArgumentOutOfRangeException(
                        "QuantityAvailable", value,
                        "There must be at least 1 available coin in the denomination");
                }

                quantityAvailable = value; 
            }
        }

        #region constructors

        public Denomination(int coinValue, int quantityAvailable)
        {
            this.coinValue = coinValue;

            if (quantityAvailable <= 0)
            {
                throw new ArgumentOutOfRangeException(
                    "quantityAvailable", quantityAvailable, 
                    "There must be at least 1 available coin in the denomination");
            }

            this.quantityAvailable = quantityAvailable;
        }

        public Denomination(int coinValue)
            : this(coinValue, int.MaxValue)
        {
        }

        /* Prevent default constructor from being called,
         * as CoinValue must be initialised:
         */
        protected Denomination()
        {
        }

        #endregion
    }
}
